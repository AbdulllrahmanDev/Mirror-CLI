import{_ as m}from"../chunks/ChLnElJx.js";export{m as component};
